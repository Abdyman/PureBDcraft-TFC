# PureBDcraft texture patch for TerraFirmaCraft
[BDcraft.net texture patch thread](https://bdcraft.net/community/work-progress-f8/terrafirmacraft-t1255.html).

[Mod page](https://www.curseforge.com/minecraft/mc-mods/tfcraft).

# Contributing
If you want to help then make a PR.

If you find a bug you can make an issue here or post in the patch thread (linked above).

# License
Please see [this thread](http://bdcraft.net/community/pbdc-patches-rel/rules-read-this-before-posting-mod-support-patch-t312.html) on the BDcraft forums.
